import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Beverages'),
        centerTitle: true,
      ),
      body:Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('Welcome to the Home Screen'),
              SizedBox(height: 30),
            ],
          ),
          Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [ElevatedButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/screen2');
                  },
                  child: const Text('Go to Screen 2'),
                ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/screen3');
                    },
                    child: const Text('Go to Screen 3'),
                  ),],
              ),
              const SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/screen4');
                    },
                    child: const Text('Go to Screen 4'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/screen5');
                    },
                    child: const Text('Go to Screen 5'),
                  ),
                ],
              ),

            ],
          ),
        ],
      )

    );
  }
}
