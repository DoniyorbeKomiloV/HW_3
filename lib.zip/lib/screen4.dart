import 'package:flutter/material.dart';

class Screen4 extends StatefulWidget {
  const Screen4({super.key});

  @override
  State<Screen4> createState() => _Screen4State();
}

class _Screen4State extends State<Screen4> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  void _decrementCounter() {
    setState(() {
      _counter--;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Screen 4'),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back),
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  "images/cola.jpg",
                  width: 360,
                  height: 270,
                ),
              ],
            ),
          ),
          const Text("Coca-cola"),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              const Text("Coca-cola 1.5l"),
              Row(
                children: [
                  ElevatedButton(
                    onPressed: _decrementCounter,
                    child: const Text(' - '),
                  ),

                  ElevatedButton(
                    onPressed: _incrementCounter,
                    child: const Text(' + '),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),

    );
  }
}
